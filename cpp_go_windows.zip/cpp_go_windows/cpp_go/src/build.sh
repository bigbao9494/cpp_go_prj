#! /bin/sh

buildType="debug"

if [ -z $1 ]; then
	echo ""
else
	echo "set release"
	buildType="release"
fi


if test $buildType = "release"; then
	echo $buildType
	##sed -i "s/as  -o \"\$@\" \"$<\"/gcc  -o \"\$@\" -c \"$<\"/g" ../Release/subdir.mk
	sed -i "s/as  -o \"\$@\" \"$<\"/gcc  -o \"\$@\" -c \"$<\"/g" ../Release/src/context/arch/subdir.mk
	sed -i "s/as  -o \"\$@\" \"$<\"/gcc  -o \"\$@\" -c \"$<\"/g" ../Release/src/context/arch/x64/subdir.mk
	cd ../Release
	#make clean
	make all
	cd ../src
elif test $buildType = "debug"; then
	echo "debug"
	##sed -i "s/as  -o \"\$@\" \"$<\"/gcc  -o \"\$@\" -c \"$<\"/g" ../Debug/subdir.mk
	sed -i "s/as  -o \"\$@\" \"$<\"/gcc  -o \"\$@\" -c \"$<\"/g" ../Debug/src/context/arch/subdir.mk
	sed -i "s/as  -o \"\$@\" \"$<\"/gcc  -o \"\$@\" -c \"$<\"/g" ../Debug/src/context/arch/x64/subdir.mk
	cd ../Debug
	#make clean
	make all
	cd ../src
fi



